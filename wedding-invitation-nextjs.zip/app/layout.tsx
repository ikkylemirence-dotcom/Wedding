import type { Metadata } from "next";
import { Great_Vibes, Cormorant_Garamond, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const greatVibes = Great_Vibes({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-great-vibes",
});

const cormorant = Cormorant_Garamond({
  weight: ["300", "400", "500", "600", "700"],
  subsets: ["latin"],
  variable: "--font-cormorant",
});

const jakarta = Plus_Jakarta_Sans({
  weight: ["300", "400", "500", "600"],
  subsets: ["latin"],
  variable: "--font-jakarta",
});

export const metadata: Metadata = {
  title: "The Wedding of Ikky Alexander & Anastasias Gracias",
  description: "Kami mengundang Bapak/Ibu/Saudara/i untuk merayakan hari bahagia pernikahan kami.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body className={`${greatVibes.variable} ${cormorant.variable} ${jakarta.variable} font-sans bg-cream text-charcoal`}>
        {children}
      </body>
    </html>
  );
}
