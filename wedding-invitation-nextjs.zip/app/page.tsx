"use client";

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Heart, Calendar, MapPin, Music, Volume2, VolumeX, 
  Send, Gift, CheckCircle, Clock, Copy, ChevronDown, Sparkles 
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface GuestWish {
  id: string;
  name: string;
  attendance: 'hadir' | 'tidak';
  pax: number;
  message: string;
  date: string;
}

export default function WeddingPage() {
  const [isOpen, setIsOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Countdown State (30 days from now)
  const [timeLeft, setTimeLeft] = useState({ days: 30, hours: 0, minutes: 0, seconds: 0 });

  // RSVP Form State
  const [guestName, setGuestName] = useState('');
  const [attendance, setAttendance] = useState<'hadir' | 'tidak'>('hadir');
  const [pax, setPax] = useState('1');
  const [message, setMessage] = useState('');
  const [wishes, setWishes] = useState<GuestWish[]>([
    { id: '1', name: 'Rizky & Partner', attendance: 'hadir', pax: 2, message: 'Selamat menempuh hidup baru Ikky & Anastasias! Semoga bahagia selalu sampai maut memisahkan.', date: 'Baru saja' },
    { id: '2', name: 'Sarah Geraldine', attendance: 'hadir', pax: 1, message: 'So happy for both of you! Lots of love on your special day.', date: '10 menit lalu' },
  ]);
  const [submitted, setSubmitted] = useState(false);
  const [copiedBCA, setCopiedBCA] = useState(false);
  const [copiedMandiri, setCopiedMandiri] = useState(false);

  // Countdown timer logic
  useEffect(() => {
    // Target date 30 days ahead from today
    const targetDate = new Date().getTime() + (30 * 24 * 60 * 60 * 1000);

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, minutes, seconds });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Audio Handler
  const toggleMusic = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  };

  const handleOpenInvitation = () => {
    setIsOpen(true);
    setIsPlaying(true);
    if (audioRef.current) {
      audioRef.current.play().catch(() => {});
    }
  };

  const handleRSVPSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;

    const newWish: GuestWish = {
      id: Date.now().toString(),
      name: guestName,
      attendance,
      pax: parseInt(pax),
      message,
      date: 'Baru saja'
    };

    setWishes([newWish, ...wishes]);
    setSubmitted(true);
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  const copyToClipboard = (text: string, type: 'bca' | 'mandiri') => {
    navigator.clipboard.writeText(text);
    if (type === 'bca') {
      setCopiedBCA(true);
      setTimeout(() => setCopiedBCA(false), 2000);
    } else {
      setCopiedMandiri(true);
      setTimeout(() => setCopiedMandiri(false), 2000);
    }
  };

  return (
    <main className="min-h-screen bg-cream text-charcoal relative overflow-x-hidden">
      {/* Background Audio ("To the Bone" Instrumental / Lofi Link) */}
      <audio 
        ref={audioRef} 
        loop 
        src="https://www.bensound.com/bensound-music/bensound-tenderness.mp3" 
      />

      {/* Opening Cover Screen */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div 
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, y: -100 }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-charcoal text-cream px-6 text-center bg-cover bg-center"
            style={{ backgroundImage: 'linear-gradient(rgba(26,26,26,0.85), rgba(26,26,26,0.92)), url("https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1920&q=80")' }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="max-w-md w-full border border-champagne/40 p-8 rounded-2xl backdrop-blur-md bg-charcoal/50 shadow-2xl relative"
            >
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-champagne text-charcoal px-4 py-1 rounded-full text-xs tracking-widest uppercase font-semibold">
                The Wedding Invitation
              </div>

              <span className="text-champagne font-serif tracking-widest text-sm uppercase block mt-4">Kepada Yth.</span>
              <h3 className="text-2xl font-serif text-cream mt-1 mb-6 font-medium">Bapak/Ibu/Saudara/i</h3>

              <div className="w-16 h-[1px] bg-champagne/50 mx-auto my-4"></div>

              <h1 className="font-script text-5xl md:text-6xl text-champagne my-4 drop-shadow-md">
                Ikky & Anastasias
              </h1>

              <p className="text-xs text-cream/70 tracking-wider mb-8">
                Tanpa mengurangi rasa hormat, kami mengundang Anda untuk hadir di hari bahagia pernikahan kami.
              </p>

              <button
                onClick={handleOpenInvitation}
                className="w-full py-3.5 px-6 bg-champagne hover:bg-champagne-dark text-charcoal font-semibold rounded-xl shadow-lg transition-all duration-300 flex items-center justify-center space-x-2 group text-sm tracking-wide"
              >
                <Heart className="w-4 h-4 fill-charcoal group-hover:scale-110 transition-transform" />
                <span>Buka Undangan</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Audio Control Button */}
      {isOpen && (
        <motion.button
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          onClick={toggleMusic}
          className="fixed bottom-6 right-6 z-40 bg-champagne text-charcoal p-3.5 rounded-full shadow-xl hover:bg-champagne-dark transition-all flex items-center justify-center border border-white/40"
          title="Toggle Music"
        >
          {isPlaying ? (
            <Volume2 className="w-5 h-5 animate-pulse" />
          ) : (
            <VolumeX className="w-5 h-5 text-charcoal/60" />
          )}
        </motion.button>
      )}

      {/* HERO SECTION */}
      <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-6 py-20 bg-gradient-to-b from-charcoal/90 to-charcoal text-cream">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center opacity-25 mix-blend-overlay"></div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isOpen ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.3 }}
          className="relative z-10 max-w-2xl mx-auto"
        >
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full border border-champagne/30 bg-champagne/10 text-champagne mb-6 text-xs tracking-widest uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The Wedding of</span>
          </div>

          <h1 className="font-script text-6xl md:text-8xl text-champagne mb-4 drop-shadow-lg">
            Ikky Alexander <br />
            <span className="text-4xl md:text-5xl font-serif italic text-cream/90">&amp;</span> <br />
            Anastasias Gracias
          </h1>

          <p className="font-serif text-lg md:text-xl text-cream/80 tracking-wide max-w-lg mx-auto mb-10">
            "Dan di antara tanda-tanda kebesaran-Nya ialah Dia menciptakan pasangan-pasangan untukmu dari jenismu sendiri..."
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-sm tracking-wider text-champagne font-medium mb-12">
            <div className="flex items-center space-x-2 bg-charcoal/60 border border-champagne/30 px-5 py-2.5 rounded-full backdrop-blur-sm">
              <Calendar className="w-4 h-4" />
              <span>Sabtu, 07 November 2026</span>
            </div>
            <div className="flex items-center space-x-2 bg-charcoal/60 border border-champagne/30 px-5 py-2.5 rounded-full backdrop-blur-sm">
              <MapPin className="w-4 h-4" />
              <span>Surabaya, Jawa Timur</span>
            </div>
          </div>

          {/* COUNTDOWN TIMER (30 days) */}
          <div className="grid grid-cols-4 gap-3 max-w-md mx-auto mb-10">
            {[
              { label: 'Hari', value: timeLeft.days },
              { label: 'Jam', value: timeLeft.hours },
              { label: 'Menit', value: timeLeft.minutes },
              { label: 'Detik', value: timeLeft.seconds },
            ].map((item, idx) => (
              <div key={idx} className="bg-charcoal/80 border border-champagne/30 p-3 rounded-xl backdrop-blur-md">
                <div className="text-2xl md:text-3xl font-serif font-bold text-champagne">{item.value}</div>
                <div className="text-[10px] md:text-xs text-cream/70 uppercase tracking-widest mt-1">{item.label}</div>
              </div>
            ))}
          </div>

          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="mt-6 inline-block text-champagne/70"
          >
            <ChevronDown className="w-6 h-6 mx-auto" />
          </motion.div>
        </motion.div>
      </section>

      {/* COUPLE SECTION */}
      <section className="py-24 px-6 max-w-5xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-champagne-dark font-serif tracking-widest uppercase text-sm block mb-2">Mempelai Bahagia</span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold mb-6 text-charcoal">Assalamu'alaikum Wr. Wb. / Shalom</h2>
          <p className="text-charcoal-muted max-w-2xl mx-auto mb-16 text-sm md:text-base leading-relaxed">
            Dengan memohon rahmat dan ridho Tuhan Yang Maha Esa, kami bermaksud mengundang Bapak/Ibu/Saudara/i sekalian dalam acara pernikahan kami.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Groom */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center bg-white p-8 rounded-3xl shadow-xl border border-champagne/20"
          >
            <div className="w-48 h-48 rounded-full overflow-hidden mb-6 border-4 border-champagne/40 shadow-md">
              <img 
                src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=600&q=80" 
                alt="Ikky Alexander"
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="font-script text-4xl text-champagne-dark mb-2">Ikky Alexander, S.T.</h3>
            <p className="text-xs uppercase tracking-widest text-charcoal-muted font-semibold mb-4">Putra Kedua Dari</p>
            <p className="text-sm text-charcoal font-medium">Bapak Alexander & Ibu Maria</p>
          </motion.div>

          {/* Bride */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center bg-white p-8 rounded-3xl shadow-xl border border-champagne/20"
          >
            <div className="w-48 h-48 rounded-full overflow-hidden mb-6 border-4 border-champagne/40 shadow-md">
              <img 
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80" 
                alt="Anastasias Gracias"
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="font-script text-4xl text-champagne-dark mb-2">Anastasias Gracias, S.Arch.</h3>
            <p className="text-xs uppercase tracking-widest text-charcoal-muted font-semibold mb-4">Putri Pertama Dari</p>
            <p className="text-sm text-charcoal font-medium">Bapak Gracias & Ibu Elizabeth</p>
          </motion.div>
        </div>
      </section>

      {/* EVENT DETAILS SECTION */}
      <section className="py-20 px-6 bg-champagne-light/50 border-y border-champagne/20">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <span className="text-champagne-dark font-serif tracking-widest uppercase text-sm block mb-2">Rangkaian Acara</span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-charcoal">Save The Date</h2>
          <div className="w-20 h-1 bg-champagne mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Akad */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white p-8 rounded-3xl shadow-xl border border-champagne/30 text-center flex flex-col justify-between"
          >
            <div>
              <div className="inline-block p-4 rounded-full bg-champagne/10 text-champagne-dark mb-6">
                <Heart className="w-8 h-8 fill-champagne/20" />
              </div>
              <h3 className="font-serif text-2xl font-bold mb-3 text-charcoal">Akad Nikah</h3>
              <p className="text-champagne-dark font-semibold text-sm mb-2">Sabtu, 07 November 2026</p>
              <p className="text-charcoal-muted text-sm mb-6">Pukul 08.00 - 10.00 WIB</p>
              <div className="bg-cream p-4 rounded-2xl mb-6">
                <p className="font-semibold text-sm text-charcoal">The Majapahit Ballroom</p>
                <p className="text-xs text-charcoal-muted mt-1">Jl. Tunjungan No. 65, Genteng, Kota Surabaya</p>
              </div>
            </div>
            <a 
              href="https://maps.google.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full py-3 bg-charcoal hover:bg-charcoal-muted text-cream rounded-xl text-xs font-semibold tracking-wider transition-colors inline-flex items-center justify-center space-x-2"
            >
              <MapPin className="w-4 h-4 text-champagne" />
              <span>Buka Google Maps</span>
            </a>
          </motion.div>

          {/* Resepsi */}
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white p-8 rounded-3xl shadow-xl border border-champagne/30 text-center flex flex-col justify-between"
          >
            <div>
              <div className="inline-block p-4 rounded-full bg-champagne/10 text-champagne-dark mb-6">
                <Calendar className="w-8 h-8" />
              </div>
              <h3 className="font-serif text-2xl font-bold mb-3 text-charcoal">Resepsi Pernikahan</h3>
              <p className="text-champagne-dark font-semibold text-sm mb-2">Sabtu, 07 November 2026</p>
              <p className="text-charcoal-muted text-sm mb-6">Pukul 11.00 - 14.00 WIB</p>
              <div className="bg-cream p-4 rounded-2xl mb-6">
                <p className="font-semibold text-sm text-charcoal">The Majapahit Ballroom</p>
                <p className="text-xs text-charcoal-muted mt-1">Jl. Tunjungan No. 65, Genteng, Kota Surabaya</p>
              </div>
            </div>
            <a 
              href="https://maps.google.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full py-3 bg-charcoal hover:bg-charcoal-muted text-cream rounded-xl text-xs font-semibold tracking-wider transition-colors inline-flex items-center justify-center space-x-2"
            >
              <MapPin className="w-4 h-4 text-champagne" />
              <span>Buka Google Maps</span>
            </a>
          </motion.div>
        </div>
      </section>

      {/* RSVP & WISHES SECTION */}
      <section className="py-24 px-6 max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-champagne-dark font-serif tracking-widest uppercase text-sm block mb-2">Konfirmasi Kehadiran</span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-charcoal">RSVP &amp; Ucapan</h2>
          <div className="w-20 h-1 bg-champagne mx-auto mt-4"></div>
        </div>

        {/* RSVP Form */}
        <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl border border-champagne/20 mb-16">
          <form onSubmit={handleRSVPSubmit} className="space-y-6">
            <div>
              <label className="block text-xs uppercase tracking-widest text-charcoal-muted font-semibold mb-2">Nama Lengkap</label>
              <input 
                type="text" 
                required
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="Masukkan nama Anda..."
                className="w-full px-4 py-3 rounded-xl border border-champagne/40 bg-cream/50 focus:outline-none focus:border-champagne text-sm"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs uppercase tracking-widest text-charcoal-muted font-semibold mb-2">Konfirmasi Kehadiran</label>
                <select 
                  value={attendance}
                  onChange={(e) => setAttendance(e.target.value as 'hadir' | 'tidak')}
                  className="w-full px-4 py-3 rounded-xl border border-champagne/40 bg-cream/50 focus:outline-none focus:border-champagne text-sm"
                >
                  <option value="hadir">Hadir (Ya, saya akan datang)</option>
                  <option value="tidak">Tidak Bisa Hadir</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-widest text-charcoal-muted font-semibold mb-2">Jumlah Tamu</label>
                <select 
                  value={pax}
                  onChange={(e) => setPax(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-champagne/40 bg-cream/50 focus:outline-none focus:border-champagne text-sm"
                >
                  <option value="1">1 Orang</option>
                  <option value="2">2 Orang</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-widest text-charcoal-muted font-semibold mb-2">Ucapan &amp; Doa Restu</label>
              <textarea 
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tuliskan ucapan atau doa untuk kedua mempelai..."
                className="w-full px-4 py-3 rounded-xl border border-champagne/40 bg-cream/50 focus:outline-none focus:border-champagne text-sm"
              ></textarea>
            </div>

            <button 
              type="submit"
              className="w-full py-4 bg-champagne hover:bg-champagne-dark text-charcoal font-semibold rounded-xl shadow-lg transition-all duration-300 flex items-center justify-center space-x-2 text-sm tracking-wide"
            >
              <Send className="w-4 h-4" />
              <span>Kirim Konfirmasi &amp; Ucapan</span>
            </button>
          </form>

          {submitted && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl flex items-center space-x-3 text-sm"
            >
              <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
              <span>Terima kasih! Konfirmasi kehadiran dan ucapan Anda berhasil dikirim.</span>
            </motion.div>
          )}
        </div>

        {/* Wishes Wall */}
        <div className="space-y-4">
          <h3 className="font-serif text-2xl font-bold text-charcoal mb-6 text-center">Ucapan &amp; Doa Tamu ({wishes.length})</h3>
          <div className="max-h-[500px] overflow-y-auto space-y-4 pr-2">
            {wishes.map((wish) => (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                key={wish.id} 
                className="bg-white p-6 rounded-2xl shadow-md border border-champagne/20"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-charcoal">{wish.name}</span>
                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-semibold uppercase tracking-wider ${wish.attendance === 'hadir' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                      {wish.attendance === 'hadir' ? 'Hadir' : 'Tidak Hadir'}
                    </span>
                  </div>
                  <span className="text-xs text-charcoal-muted flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{wish.date}</span>
                  </span>
                </div>
                <p className="text-sm text-charcoal-muted leading-relaxed">{wish.message}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* DIGITAL ENVELOPE SECTION */}
      <section className="py-20 px-6 bg-charcoal text-cream text-center">
        <div className="max-w-3xl mx-auto">
          <span className="text-champagne font-serif tracking-widest uppercase text-sm block mb-2">Tanda Kasih</span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">Amplop Digital</h2>
          <p className="text-cream/70 text-sm md:text-base max-w-lg mx-auto mb-12">
            Doa restu Anda merupakan karunia yang sangat berarti bagi kami. Dan jika memberi adalah ungkapan tanda kasih, Anda dapat mengirimkannya melalui:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* BCA */}
            <div className="bg-charcoal-muted/40 border border-champagne/30 p-8 rounded-3xl backdrop-blur-md flex flex-col justify-between">
              <div>
                <div className="text-champagne font-bold text-xl tracking-wider mb-2">BANK BCA</div>
                <div className="text-2xl font-mono font-bold tracking-widest text-cream my-4">8830912345</div>
                <div className="text-xs text-cream/70 uppercase tracking-widest mb-6">a.n. Ikky Alexander</div>
              </div>
              <button 
                onClick={() => copyToClipboard('8830912345', 'bca')}
                className="w-full py-3 bg-champagne hover:bg-champagne-dark text-charcoal font-semibold rounded-xl text-xs tracking-wider transition-colors inline-flex items-center justify-center space-x-2"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedBCA ? 'Berhasil Disalin!' : 'Salin Nomor Rekening'}</span>
              </button>
            </div>

            {/* Mandiri */}
            <div className="bg-charcoal-muted/40 border border-champagne/30 p-8 rounded-3xl backdrop-blur-md flex flex-col justify-between">
              <div>
                <div className="text-champagne font-bold text-xl tracking-wider mb-2">BANK MANDIRI</div>
                <div className="text-2xl font-mono font-bold tracking-widest text-cream my-4">1420019876543</div>
                <div className="text-xs text-cream/70 uppercase tracking-widest mb-6">a.n. Anastasias Gracias</div>
              </div>
              <button 
                onClick={() => copyToClipboard('1420019876543', 'mandiri')}
                className="w-full py-3 bg-champagne hover:bg-champagne-dark text-charcoal font-semibold rounded-xl text-xs tracking-wider transition-colors inline-flex items-center justify-center space-x-2"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedMandiri ? 'Berhasil Disalin!' : 'Salin Nomor Rekening'}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-12 px-6 bg-charcoal border-t border-champagne/20 text-center text-cream/60 text-xs">
        <p className="font-serif text-2xl text-champagne mb-4 font-script">Ikky &amp; Anastasias</p>
        <p>Merupakan suatu kehormatan dan kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan hadir.</p>
        <p className="mt-6 text-cream/40">&copy; 2026 Wedding Invitation. All rights reserved.</p>
      </footer>
    </main>
  );
}
