import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        champagne: {
          light: "#F7F2EA",
          DEFAULT: "#D4AF37",
          dark: "#997A15",
        },
        cream: {
          DEFAULT: "#FDFBF7",
          dark: "#F3EDE2",
        },
        charcoal: {
          DEFAULT: "#1A1A1A",
          muted: "#4A4A4A",
        }
      },
      fontFamily: {
        script: ["var(--font-great-vibes)", "cursive"],
        serif: ["var(--font-cormorant)", "serif"],
        sans: ["var(--font-jakarta)", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
