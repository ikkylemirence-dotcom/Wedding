# Digital Wedding Invitation - Next.js & Tailwind CSS

Undangan pernikahan digital profesional dan elegan untuk **Ikky Alexander & Anastasias Gracias**, dibangun menggunakan **Next.js (App Router)**, **Tailwind CSS**, dan **Framer Motion**.

## Fitur Utama
1. **Cover Pembuka Interaktif:** Dengan tombol "Buka Undangan" dan pemutar musik latar belakang otomatis.
2. **Animasi Halus (Framer Motion):** Transisi elemen, tombol, dan card yang elegan.
3. **Hitung Mundur (Countdown Timer):** Dinamis 30 hari menuju hari pernikahan.
4. **RSVP & Buku Tamu Interaktif:** Tamu dapat memilih status Hadir / Tidak Bisa Hadir, menentukan jumlah pax, menuliskan ucapan dan doa yang langsung tampil di dinding ucapan (Wishes Wall) lengkap dengan efek konfeti.
5. **Amplop Digital:** Integrasi nomor rekening BCA & Mandiri dengan fitur salin sekali klik (copy to clipboard).
6. **Desain Kelas Profesional:** Palet warna Champagne Gold, Soft Cream, dan Deep Charcoal dengan font tipografi mewah (*Great Vibes*, *Cormorant Garamond*, *Plus Jakarta Sans*).

## Cara Menjalankan (Development)

1. Pastikan Anda sudah menginstal [Node.js](https://nodejs.org/) di komputer Anda.
2. Ekstrak file ZIP ini ke direktori pilihan Anda.
3. Buka terminal pada folder proyek, lalu instal dependensi:
   ```bash
   npm install
   ```
4. Jalankan server development:
   ```bash
   npm run dev
   ```
5. Buka browser di `http://localhost:3000`.

## Deployment ke Vercel / GitHub
Proyek ini siap di-deploy langsung ke Vercel atau di-push ke repository GitHub Anda.
